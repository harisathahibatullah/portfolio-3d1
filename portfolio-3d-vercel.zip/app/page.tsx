import Scene from "@/components/Scene";
import { ArrowUpRight, Github, Linkedin, Mail, Menu, Sparkles, Code2, Layers3, Smartphone } from "lucide-react";

const projects = [
  { number: "01", title: "NEXA Dashboard", type: "UI/UX · FRONTEND", description: "Dashboard analitik modern dengan visualisasi data yang intuitif.", tags: ["Next.js", "TypeScript", "Charts"], color: "cyan" },
  { number: "02", title: "Orbit Commerce", type: "WEB DEVELOPMENT", description: "Pengalaman e-commerce yang cepat, responsif, dan berorientasi pengguna.", tags: ["React", "API", "CSS"], color: "purple" },
  { number: "03", title: "Aether Studio", type: "CREATIVE DEVELOPMENT", description: "Landing page eksperimental dengan motion dan interaksi mikro.", tags: ["Three.js", "Motion", "WebGL"], color: "pink" },
];

export default function Home() {
  return (
    <main>
      <div className="ambient ambient-one" /><div className="ambient ambient-two" />
      <nav className="nav wrap">
        <a className="brand" href="#home"><span className="brand-mark">H.</span><span>PORTFOLIO<span className="brand-dot">_</span></span></a>
        <div className="nav-links"><a href="#about">About</a><a href="#projects">Projects</a><a href="#skills">Skills</a><a href="#contact">Contact</a></div>
        <a className="nav-cta" href="#contact">LET&apos;S TALK <ArrowUpRight size={15}/></a>
        <a className="mobile-menu" href="#contact" aria-label="Menu"><Menu /></a>
      </nav>

      <section className="hero wrap" id="home">
        <div className="hero-copy">
          <div className="eyebrow"><span className="status-dot" /> AVAILABLE FOR OPPORTUNITIES</div>
          <p className="intro">HELLO, I&apos;M</p>
          <h1>HARIS<br/><span>ATHA</span><i>.</i></h1>
          <div className="role-line"><span className="line" /> <span>CREATIVE DEVELOPER</span></div>
          <p className="hero-desc">Membangun pengalaman digital yang berani, fungsional, dan punya karakter. Menggabungkan desain, teknologi, dan sedikit eksperimen.</p>
          <div className="hero-actions"><a className="button-primary" href="#projects">EXPLORE MY WORK <ArrowUpRight size={16}/></a><a className="button-ghost" href="#about">MORE ABOUT ME <span>↓</span></a></div>
          <div className="hero-meta"><div><strong>03<span>+</span></strong><small>SELECTED PROJECTS</small></div><div><strong>100<span>%</span></strong><small>PASSION & CURIOSITY</small></div></div>
        </div>
        <div className="hero-visual">
          <div className="visual-label label-top"><span>FIG. 001</span><span>3D OBJECT / 2026</span></div>
          <Scene />
          <div className="orbit-caption"><span className="caption-dot"/> DIGITAL UNIVERSE <span>— 01</span></div>
          <div className="visual-cross cross-one">+</div><div className="visual-cross cross-two">+</div>
        </div>
        <div className="scroll-hint"><span/> SCROLL TO DISCOVER</div>
      </section>

      <section className="ticker"><div className="ticker-track"><span>DESIGN WITH PURPOSE ✳ BUILD WITH PASSION ✳ THINK BEYOND ✳</span><span>DESIGN WITH PURPOSE ✳ BUILD WITH PASSION ✳ THINK BEYOND ✳</span></div></section>

      <section className="section wrap about-section" id="about">
        <div className="section-kicker">01 / ABOUT ME</div>
        <div className="about-grid"><div><h2>Turning ideas<br/>into <span>digital reality.</span></h2></div><div className="about-copy"><p>Saya adalah individu yang tertarik pada dunia teknologi, desain antarmuka, dan pengembangan web. Saya senang mengeksplorasi ide baru lalu mengubahnya menjadi produk digital yang mudah digunakan dan menarik secara visual.</p><p>Fokus saya adalah terus belajar, bereksperimen, dan menciptakan karya yang memberikan pengalaman lebih baik bagi pengguna.</p><a className="text-link" href="#contact">LET&apos;S CONNECT <ArrowUpRight size={15}/></a></div></div>
        <div className="stats-row"><div><strong>01</strong><span>CREATIVE MINDSET</span></div><div><strong>02</strong><span>CONTINUOUS LEARNING</span></div><div><strong>03</strong><span>DETAIL ORIENTED</span></div></div>
      </section>

      <section className="section projects-section" id="projects"><div className="wrap">
        <div className="section-head"><div><div className="section-kicker">02 / SELECTED WORK</div><h2>Featured <span>projects.</span></h2></div><p>A selection of ideas brought to life<br/>through design and development.</p></div>
        <div className="project-list">{projects.map((project) => <article className={`project-card ${project.color}`} key={project.number}><div className="project-number">{project.number}</div><div className="project-art"><div className="art-orbit"/><div className="art-core">{project.number}</div><div className="art-ring"/></div><div className="project-info"><span className="project-type">{project.type}</span><h3>{project.title}</h3><p>{project.description}</p><div className="tags">{project.tags.map(tag => <span key={tag}>{tag}</span>)}</div></div><a className="project-arrow" href="#contact" aria-label={`Discuss ${project.title}`}><ArrowUpRight/></a></article>)}</div>
      </div></section>

      <section className="section wrap skills-section" id="skills">
        <div className="section-kicker">03 / WHAT I DO</div><div className="section-head"><h2>My creative <span>toolkit.</span></h2><p>Tools and capabilities I use<br/>to shape digital experiences.</p></div>
        <div className="skill-grid"><div className="skill-card"><Code2/><span>01</span><h3>Web Development</h3><p>Membangun website modern, responsif, dan terstruktur.</p><small>HTML · CSS · JAVASCRIPT · REACT</small></div><div className="skill-card"><Layers3/><span>02</span><h3>UI / UX Design</h3><p>Merancang antarmuka yang intuitif dengan visual yang kuat.</p><small>FIGMA · WIREFRAMING · PROTOTYPING</small></div><div className="skill-card"><Smartphone/><span>03</span><h3>Responsive Design</h3><p>Menghadirkan pengalaman konsisten di berbagai perangkat.</p><small>WEB · MOBILE · ACCESSIBILITY</small></div></div>
      </section>

      <section className="contact-section" id="contact"><div className="wrap contact-inner"><div className="section-kicker">04 / GET IN TOUCH</div><h2>Have an idea?<br/><span>Let&apos;s make it real.</span></h2><p>Terbuka untuk kolaborasi, proyek kreatif, dan kesempatan baru.</p><a className="button-primary contact-button" href="mailto:hello@example.com">SAY HELLO <ArrowUpRight size={17}/></a><div className="contact-orb">✳</div></div></section>

      <footer className="footer wrap"><a className="brand" href="#home"><span className="brand-mark">H.</span><span>PORTFOLIO<span className="brand-dot">_</span></span></a><span>© 2026 HARIS ATHA. BUILT WITH CURIOSITY.</span><div className="socials"><a href="https://github.com/" aria-label="GitHub"><Github/></a><a href="https://linkedin.com/" aria-label="LinkedIn"><Linkedin/></a><a href="mailto:hello@example.com" aria-label="Email"><Mail/></a></div></footer>
    </main>
  );
}
