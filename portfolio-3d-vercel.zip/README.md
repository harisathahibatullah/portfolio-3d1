# Portfolio 3D Futuristic Dark Neon

Template portfolio Next.js dengan objek 3D interaktif berbasis Three.js. Siap dijalankan lokal dan di-deploy ke Vercel.

## Menjalankan di komputer

1. Install Node.js versi 18 atau lebih baru.
2. Ekstrak folder project.
3. Buka terminal di folder project, lalu jalankan:

```bash
npm install
npm run dev
```

4. Buka http://localhost:3000

## Deploy ke Vercel

**Cara mudah melalui GitHub**
1. Buat repository baru di GitHub.
2. Upload seluruh isi folder project ini ke repository.
3. Login ke https://vercel.com dan pilih **Add New → Project**.
4. Import repository GitHub tersebut.
5. Framework akan terdeteksi sebagai Next.js. Klik **Deploy**.

Tidak perlu environment variable untuk template ini.

## Bagian yang perlu kamu personalisasi

Cari dan ubah di `app/page.tsx`:
- `HARIS` dan `ATHA`: nama tampilan.
- Deskripsi pada hero dan About.
- Isi array `projects`: nama, kategori, deskripsi, dan teknologi proyek.
- Daftar skill.
- `hello@example.com`: ganti dengan email kamu.
- Link GitHub dan LinkedIn di bagian footer.

Objek 3D dibuat langsung dengan Three.js di `components/Scene.tsx`. Warna, ukuran, dan kecepatan animasinya bisa disesuaikan di sana.

## Catatan

Kartu proyek dan kontak pada template ini masih memakai konten contoh. Ganti dengan informasi dan tautan milikmu sebelum dipublikasikan.
