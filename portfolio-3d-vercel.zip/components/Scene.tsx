"use client";

import { useEffect, useRef } from "react";
import * as THREE from "three";

export default function Scene() {
  const host = useRef<HTMLDivElement>(null);

  useEffect(() => {
    const el = host.current;
    if (!el) return;

    const scene = new THREE.Scene();
    const camera = new THREE.PerspectiveCamera(42, el.clientWidth / el.clientHeight, 0.1, 100);
    camera.position.set(0, 0, 8);

    const renderer = new THREE.WebGLRenderer({ alpha: true, antialias: true });
    renderer.setPixelRatio(Math.min(window.devicePixelRatio, 2));
    renderer.setSize(el.clientWidth, el.clientHeight);
    renderer.setClearColor(0x000000, 0);
    el.appendChild(renderer.domElement);

    const group = new THREE.Group();
    scene.add(group);

    const geometry = new THREE.IcosahedronGeometry(1.65, 1);
    const material = new THREE.MeshStandardMaterial({
      color: 0x101a35, metalness: 0.78, roughness: 0.2,
      wireframe: true, emissive: 0x00d9ff, emissiveIntensity: 0.65
    });
    const mesh = new THREE.Mesh(geometry, material);
    group.add(mesh);

    const core = new THREE.Mesh(
      new THREE.IcosahedronGeometry(1.15, 2),
      new THREE.MeshBasicMaterial({ color: 0x8a35ff, wireframe: true, transparent: true, opacity: 0.28 })
    );
    group.add(core);

    const ringMaterial = new THREE.MeshBasicMaterial({ color: 0x00eaff, transparent: true, opacity: 0.7 });
    const ring = new THREE.Mesh(new THREE.TorusGeometry(2.15, 0.012, 8, 160), ringMaterial);
    ring.rotation.x = 1.08;
    group.add(ring);
    const ring2 = new THREE.Mesh(new THREE.TorusGeometry(2.45, 0.008, 8, 160), new THREE.MeshBasicMaterial({ color: 0x9b5cff, transparent: true, opacity: 0.55 }));
    ring2.rotation.y = 1.1;
    ring2.rotation.x = 0.35;
    group.add(ring2);

    scene.add(new THREE.AmbientLight(0xffffff, 1.3));
    const light = new THREE.PointLight(0x00d9ff, 18, 20);
    light.position.set(3, 3, 5);
    scene.add(light);
    const violet = new THREE.PointLight(0x8a35ff, 12, 20);
    violet.position.set(-4, -2, 2);
    scene.add(violet);

    const particles = new THREE.BufferGeometry();
    const positions = new Float32Array(450 * 3);
    for (let i = 0; i < 450; i++) {
      positions[i * 3] = (Math.random() - 0.5) * 15;
      positions[i * 3 + 1] = (Math.random() - 0.5) * 10;
      positions[i * 3 + 2] = (Math.random() - 0.5) * 8;
    }
    particles.setAttribute("position", new THREE.BufferAttribute(positions, 3));
    const stars = new THREE.Points(particles, new THREE.PointsMaterial({ color: 0x74eaff, size: 0.018, transparent: true, opacity: 0.8 }));
    scene.add(stars);

    let frame = 0;
    let pointerX = 0;
    let pointerY = 0;
    const onMove = (e: MouseEvent) => {
      const rect = el.getBoundingClientRect();
      pointerX = ((e.clientX - rect.left) / rect.width - 0.5) * 0.35;
      pointerY = ((e.clientY - rect.top) / rect.height - 0.5) * 0.25;
    };
    el.addEventListener("mousemove", onMove);

    const animate = () => {
      frame = requestAnimationFrame(animate);
      group.rotation.y += 0.0025;
      group.rotation.x += 0.0012;
      group.rotation.y += (pointerX - group.rotation.y) * 0.002;
      group.rotation.x += (-pointerY - group.rotation.x) * 0.002;
      ring.rotation.z += 0.0018;
      ring2.rotation.z -= 0.0011;
      stars.rotation.y += 0.00015;
      renderer.render(scene, camera);
    };
    animate();

    const resize = () => {
      if (!el) return;
      camera.aspect = el.clientWidth / el.clientHeight;
      camera.updateProjectionMatrix();
      renderer.setSize(el.clientWidth, el.clientHeight);
    };
    window.addEventListener("resize", resize);

    return () => {
      cancelAnimationFrame(frame);
      window.removeEventListener("resize", resize);
      el.removeEventListener("mousemove", onMove);
      geometry.dispose(); material.dispose(); renderer.dispose();
      if (el.contains(renderer.domElement)) el.removeChild(renderer.domElement);
    };
  }, []);

  return <div className="scene" ref={host} aria-label="Animasi objek 3D futuristik" />;
}
